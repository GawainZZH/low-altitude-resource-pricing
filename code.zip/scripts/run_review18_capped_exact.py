"""Exact boundary Nash witnesses and plot-ready completion, same five games."""
from decimal import Decimal
from pathlib import Path
import argparse
import json
import sys
import time

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT)); sys.dont_write_bytecode=True
from experiments.aam_pricing import review18_capped_actual as a
from experiments.aam_pricing.review13_equilibrium import Interval as I, midpoint, UP
import numpy as np


def setup(c,row,bracket=None):
    s=row['state']; p=[44 if v is None else v for v in s['prices']]
    active=s['active']; env=a.FareEnvelope(c,s['charge'],p,active,0)
    work=lambda fare:env.choice(env.attractions(I(fare)),I(1))[2]-env.K
    if bracket is None:
        z=I(p[0]); l=(z-I('0.000001')).lo; r=(z+I('0.000001')).hi
        if work(l).lo<=0 or work(r).hi>=0: raise ValueError('Boundary root bracket')
        while UP.subtract(r,l)>Decimal('1e-25'):
            mid=midpoint(I(l,r)); value=work(mid)
            if value.lo>0: l=mid
            elif value.hi<0: r=mid
            else: raise ValueError('Decimal precision insufficient for root separation')
    else: l,r=map(Decimal,bracket)
    if not work(l).lo>0 or not work(r).hi<0: raise ValueError('Root endpoint signs')
    ps=[I(v) for v in p]; ps[0]=I(l,r)
    return p,ps,[str(l),str(r)]


def envelope(c,row,p,ps,m):
    env=a.FareEnvelope(c,row['state']['charge'],p,row['state']['active'],m)
    env.t=[((I(c['platform_quality'][j])-I(c['lam'])*ps[j])/I(c['mu'])).exp()
           if row['state']['active'][j] else I(0) for j in range(len(p))]
    return env


def slack_derivative(env,fare):
    t=env.attractions(fare); rho=I(0,'1.00000001')
    for _ in range(24):
        y,prob,R=env.choice(t,rho)
        narrowed=rho.intersection(R/env.K)
        if narrowed is None: raise ValueError('Free continuation unavailable')
        if narrowed.lo==rho.lo and narrowed.hi==rho.hi: break
        rho=narrowed
    y,prob,_=env.choice(t,rho)
    m=env.m; direct=I(0); yr=I(0); Rp=I(0); Rr=I(0)
    for g,n in enumerate(env.c['mass']):
        pi=prob[g][m]; theta=sum(prob[g],I(0)).intersection(I(0,1))
        if theta is None: raise ValueError('Aerial probability interval')
        work=sum((v*w for v,w in zip(env.a,prob[g])),I(0))
        b=I(env.c['reliability_slopes'][g])/I(env.c['mu'])
        direct-=env.h*I(n)*pi*(1-pi)
        yr-=I(n)*b*pi*(1-theta)
        Rp-=env.h*I(n)*pi*(env.a[m]-work)
        Rr-=I(n)*b*work*(1-theta)
    return y[m]+(fare-env.k)*(direct+yr*Rp/(env.K-Rr))


def welfare(c,row,ps):
    env=envelope(c,row,[float(x.lo) for x in ps],ps,0)
    y,_,_=env.choice(env.t,I(1)); T=sum(env.t,I(0)); cs=I(0)
    for g,n in enumerate(c['mass']):
        b=((I(c['group_quality'][g])-I(c['reliability_slopes'][g])-I(c['outside_utility'][g]))/I(c['mu'])).exp()
        cs+=I(n)*I(c['mu'])/I(c['lam'])*(I(c['outside_utility'][g])/I(c['mu'])+(1+b*T).log())
    ground=I(sum(c['mass']))-sum(y,I(0))
    return {str(k):(cs+sum(((ps[j]-I(c['costs'][j]))*y[j] for j in range(len(ps))),I(0))+
            I(k)*I(c['outside_price'])*ground).serialized() for k in a.cp.KAPPAS}


def exact_witness(c,row,deadline=None):
    a.budget(deadline); p,ps,bracket=setup(c,row)
    coordinates=[]
    for m in np.flatnonzero(row['state']['active']):
        env=envelope(c,row,p,ps,int(m)); t=env.t
        x=env.a[m]*t[m]/sum((aa*tt for aa,tt in zip(env.a,t)),I(0))
        full=env.K/env.a[m]*x*(1-env.h*(ps[m]-env.k)*(1-x))
        if full.lo<=0: raise ValueError('Full-side derivative not strictly positive')
        premises=[(I(n)*env.a[m]-env.K).serialized() for n in c['mass']]
        if any(Decimal(v[0])<=0 for v in premises): raise ValueError('Single capacity crossing premise')
        pending=[(ps[m].lo,I(c['fare_bounds'][1]).hi)] if ps[m].lo<I(c['fare_bounds'][1]).hi else []
        leaves=[]
        while pending:
            a.budget(deadline)
            if len(leaves)+len(pending)>2048: raise ValueError('Frozen sign-bound budget')
            l,r=pending.pop(); d=slack_derivative(env,I(l,r))
            if d.hi<0: leaves.append(dict(fare=[str(l),str(r)],derivative=d.serialized()))
            else:
                mid=midpoint(I(l,r))
                if UP.subtract(r,l)<Decimal('1e-18'): raise ValueError('No strict free-side sign')
                pending.extend([(mid,r),(l,mid)])
        coordinates.append(dict(firm=int(m),full_derivative=full.serialized(),
                                group_mass_resource_minus_K=premises,slack_intervals=sorted(leaves,key=lambda x:Decimal(x['fare'][0]))))
    return dict(case_id=row['case_id'],charge=row['state']['charge'],anchor_firm=0,
                root_bracket=bracket,prices=[x.serialized() if row['state']['active'][j] else None for j,x in enumerate(ps)],
                coordinates=coordinates,TS=welfare(c,row,ps),exact_global_nash_existence=True,
                exact_point_definition='Saved fares of firms 1 and 2; firm 0 is unique root R(p,1,0)=K',
                numerical_saved_vector_is_exact=False,all_equilibria_enumerated=False)


def verify(c,row,witness):
    p,ps,bracket=setup(c,row,witness['root_bracket'])
    if bracket!=witness['root_bracket']: raise ValueError('Root bracket representation')
    if [x['firm'] for x in witness['coordinates']]!=list(map(int,np.flatnonzero(row['state']['active']))):
        raise ValueError('Exact coordinate coverage')
    for coord in witness['coordinates']:
        m=coord['firm']; env=envelope(c,row,p,ps,m); t=env.t
        x=env.a[m]*t[m]/sum((aa*tt for aa,tt in zip(env.a,t)),I(0))
        full=env.K/env.a[m]*x*(1-env.h*(ps[m]-env.k)*(1-x))
        if full.serialized()!=coord['full_derivative'] or full.lo<=0: raise ValueError('Full derivative')
        premises=[(I(n)*env.a[m]-env.K).serialized() for n in c['mass']]
        if premises!=coord['group_mass_resource_minus_K'] or any(Decimal(z[0])<=0 for z in premises):
            raise ValueError('Single crossing premise')
        last=ps[m].lo
        for leaf in coord['slack_intervals']:
            l,r=map(Decimal,leaf['fare'])
            if l!=last or r<=l: raise ValueError('Free derivative coverage')
            d=slack_derivative(env,I(l,r))
            if d.serialized()!=leaf['derivative'] or d.hi>=0: raise ValueError('Free derivative sign')
            last=r
        if last!=I(c['fare_bounds'][1]).hi: raise ValueError('Free upper endpoint')
    if welfare(c,row,ps)!=witness['TS']: raise ValueError('Exact welfare enclosure')
    return dict(valid=True,exact_global_nash_existence=True,scalar_roots_called=0,optimizations_called=0)


def export(rows,witnesses,out):
    """Maintain the cp row/state container and plotting fields without old edits."""
    old=a.read(ROOT/a.OLD/'points.json'); new={(r['case_id'],r['state']['charge']):(r,w) for r,w in zip(rows,witnesses)}
    complete=[]; five=[]
    for r in old:
        replacement=new.get((r['case_id'],r['state']['charge']))
        if replacement is None:
            complete.append(r); continue
        actual,witness=replacement
        s=dict(r['state']); s.update(actual['state'])
        s.update(actual_profits=actual['state']['profits'],
                 actual_global_nash_supported=True,classification='actual_global_nash_boundary_witness',
                 numerical_exact_nash_claim=False,exact_nearby_nash_witness=witness,
                 auxiliary_only_state=r['state'],actual_global_deviation_bound=actual['proof'],
                 comparative_statics=dict(smooth_active_set=False,
                   interpretation='Zero-wait full-capacity kink; no full-capacity smooth derivative claim'))
        # Auxiliary KKT fields describe the historical vector, never the actual one.
        s['historical_auxiliary_witness']=s.pop('auxiliary_witness')
        s['historical_auxiliary_resource_shares']=s.pop('auxiliary_resource_shares')
        s['historical_auxiliary_profits']=s.pop('auxiliary_profits')
        aa=np.asarray(next(c['primitives']['resource'] for c in a.design(ROOT)['cases'] if c['id']==r['case_id']))
        s['resource_shares']=(aa*np.asarray(s['demand'])/s['resource_use']).tolist()
        c=next(c['primitives'] for c in a.design(ROOT)['cases'] if c['id']==r['case_id'])
        margins=[None if fare is None else fare-c['costs'][m]-aa[m]*s['charge']
                 for m,fare in enumerate(s['prices'])]
        s['active_margins']=margins
        s['ground_mass']=sum(c['mass'])-s['total_mass']
        s['exit_noentry']=[dict(firm=m,exited=not s['active'][m],
             maximum_feasible_margin=44-c['costs'][m]-aa[m]*s['charge'],
             nonpositive_all_fares=bool(44-c['costs'][m]-aa[m]*s['charge']<=0),
             strictly_negative_all_fares=bool(44-c['costs'][m]-aa[m]*s['charge']<0),
             positive_profit_reentry_excluded=bool(not s['active'][m] and 44-c['costs'][m]-aa[m]*s['charge']<=0),
             active_exit_gain=-s['actual_profits'][m] if s['active'][m] else 0.) for m in range(len(aa))]
        s['zero_wait_excess']=s['resource_use']-60.
        s['rho']=1.; s['wait']=0.
        s['premises']=dict(exact_boundary_Nash_witness=True,full_capacity=True,
                           historical_auxiliary_KKT_applies_to_actual_vector=False)
        row=dict(case_id=r['case_id'],status='completed',state=s)
        complete.append(row); five.append(row)
    a.write(out/'review18_capped_actual_five_plot_ready.json',five)
    a.write(out/'review18_capped_actual_44_plot_ready.json',complete)
    fields=['case_id','charge','prices','rho','wait','resource_use','total_mass','kappa0','kappa05','kappa1']
    import csv
    with (out/'review18_capped_actual_44_plot_ready.csv').open('w',newline='',encoding='utf-8') as f:
        writer=csv.DictWriter(f,fieldnames=fields); writer.writeheader()
        for row in complete:
            s=row['state']; writer.writerow(dict(case_id=row['case_id'],charge=s['charge'],prices=json.dumps(s['prices']),
              rho=s['rho'],wait=s['wait'],resource_use=s['resource_use'],total_mass=s['total_mass'],
              kappa0=s['TS']['0.0'],kappa05=s['TS']['0.5'],kappa1=s['TS']['1.0']))


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    modes=parser.add_mutually_exclusive_group()
    modes.add_argument('--replay',action='store_true'); modes.add_argument('--export-only',action='store_true')
    args=parser.parse_args()
    out=ROOT/a.OUTPUT; rows=a.read(out/'points.json')
    cases={c['id']:c['primitives'] for c in a.design(ROOT)['cases']}
    target=out/'review18_capped_exact_witnesses.json'
    start=time.monotonic()
    if args.replay or args.export_only:
        witnesses=a.read(target)
        if len(witnesses)!=5 or len(rows)!=5: raise ValueError('Five exact witnesses required')
        for row,w in zip(rows,witnesses): verify(cases[row['case_id']],row,w)
        if args.export_only:
            export(rows,witnesses,out)
            a.write(out/'review18_capped_exact_source_manifest.json',{p:a.digest(ROOT/p) for p in
                ('scripts/run_review18_capped_exact.py','tests/test_review18_capped_exact.py')})
        print(json.dumps(dict(valid=True,games=len(witnesses),scalar_roots_called=0,optimizations_called=0)))
        return
    if target.exists(): raise FileExistsError('Exact proof pass already saved; replay only')
    witnesses=[exact_witness(cases[row['case_id']],row,start+90) for row in rows]
    a.write(target,witnesses); export(rows,witnesses,out)
    result=dict(exact_global_nash_games=len(witnesses),new_tariff_games=0,
                elapsed_seconds=time.monotonic()-start,
                strict_free_derivative_intervals=sum(len(z['slack_intervals']) for w in witnesses for z in w['coordinates']),
                all_equilibria_enumerated=False)
    a.write(out/'review18_capped_exact_execution.json',result)
    a.write(out/'review18_capped_exact_source_manifest.json',{p:a.digest(ROOT/p) for p in
       ('scripts/run_review18_capped_exact.py','tests/test_review18_capped_exact.py')})
    print(json.dumps(result,indent=2))


if __name__=='__main__': main()
